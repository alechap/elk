<?php 
require 'vendor/autoload.php';

$client = Elasticsearch\ClientBuilder::create()->build();

?>